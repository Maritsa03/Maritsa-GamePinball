using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SFXAudioController : MonoBehaviour
{
    private void Start()
	{
		Destroy(gameObject, 1.0f);
	}
}
